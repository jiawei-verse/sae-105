# Accès au site
URL du site: http://pang.projetsmmichamps.fr/sae105

# Procédure de mise en ligne:
1. Se connecter au site sur FileZilla avec le login et le mot de passe (si jamais connecté, créer un nouveau avec comme Hôte l'URL).
2. Mettre en ligne le dossier du site dans le dossier "public_html" sur le site distant (colonne droite). Soi en servant de la colonne de gauche, soi en glissant simplement le dossier dans "public_html".

# Autres
Checklist Opquast: https://docs.google.com/spreadsheets/d/19MVIz7zLyk-lgSJ3hgh10IVYYiHAok7BKj_gzkDVQac/edit?gid=0#gid=0